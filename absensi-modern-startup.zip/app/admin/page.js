
"use client";

import { Bar } from "react-chartjs-2";
import {
Chart as ChartJS,
CategoryScale,
LinearScale,
BarElement,
Title,
Tooltip,
Legend
} from "chart.js";

ChartJS.register(
CategoryScale,
LinearScale,
BarElement,
Title,
Tooltip,
Legend
);

export default function Admin(){

const data = {
labels:["Senin","Selasa","Rabu","Kamis","Jumat"],
datasets:[
{
label:"Kehadiran",
data:[20,18,22,19,23]
}
]
};

return(

<div className="p-10">

<h1 className="text-3xl font-bold mb-6">
Dashboard Admin
</h1>

<div className="bg-white p-6 rounded shadow w-96">
<Bar data={data} />
</div>

</div>

);

}
