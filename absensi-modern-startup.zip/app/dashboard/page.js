
"use client";

import { useRef, useState } from "react";

export default function Dashboard(){

const videoRef = useRef(null);
const canvasRef = useRef(null);
const [status,setStatus] = useState("");

async function startCamera(){

const stream = await navigator.mediaDevices.getUserMedia({video:true});
videoRef.current.srcObject = stream;

}

function capture(){

const canvas = canvasRef.current;
const video = videoRef.current;

canvas.width = video.videoWidth;
canvas.height = video.videoHeight;

const ctx = canvas.getContext("2d");
ctx.drawImage(video,0,0);

setStatus("Selfie berhasil diambil untuk absensi");

}

return(

<div className="p-10 flex flex-col items-center gap-4">

<h1 className="text-3xl font-bold">
Dashboard Absensi
</h1>

<button
onClick={startCamera}
className="bg-blue-500 text-white px-4 py-2 rounded"
>
Aktifkan Kamera
</button>

<video
ref={videoRef}
autoPlay
className="w-64 border"
></video>

<button
onClick={capture}
className="bg-green-500 text-white px-4 py-2 rounded"
>
Selfie Absen
</button>

<canvas
ref={canvasRef}
className="hidden"
></canvas>

<p>{status}</p>

</div>

);

}
