
import Link from "next/link";

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center h-screen gap-6">
      <h1 className="text-4xl font-bold">Absensi Modern Startup</h1>

      <div className="flex gap-4">
        <Link href="/login">
          <button className="bg-blue-500 text-white px-6 py-3 rounded">
            Login
          </button>
        </Link>

        <Link href="/admin">
          <button className="bg-purple-500 text-white px-6 py-3 rounded">
            Admin
          </button>
        </Link>
      </div>
    </main>
  );
}
