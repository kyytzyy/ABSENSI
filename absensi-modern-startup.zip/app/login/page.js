
"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function Login(){

const router = useRouter();
const [email,setEmail] = useState("");

function login(){

if(email === "admin@gmail.com"){
router.push("/admin");
}else{
router.push("/dashboard");
}

}

return(

<div className="flex flex-col items-center justify-center h-screen gap-4">

<h1 className="text-2xl font-bold">
Login Absensi
</h1>

<input
placeholder="Email"
className="border p-2"
onChange={(e)=>setEmail(e.target.value)}
/>

<button
onClick={login}
className="bg-green-500 text-white px-6 py-2 rounded"
>
Login
</button>

</div>

);

}
