
export const metadata = {
  title: "Absensi Modern",
  description: "Website absensi modern"
};

export default function RootLayout({ children }) {
  return (
    <html>
      <head>
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body className="bg-gray-100">
        {children}
      </body>
    </html>
  );
}
