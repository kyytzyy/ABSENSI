
"use client";

import { useEffect } from "react";
import { Html5Qrcode } from "html5-qrcode";

export default function Scan(){

useEffect(()=>{

const scanner = new Html5Qrcode("reader");

scanner.start(
{ facingMode: "environment" },
{ fps: 10, qrbox: 250 },
(decodedText)=>{
alert("QR berhasil di scan: " + decodedText);
}
);

},[]);

return(

<div className="p-10">

<h1 className="text-3xl font-bold mb-4">
Scan QR Absensi
</h1>

<div id="reader" className="w-72"></div>

</div>

);

}
