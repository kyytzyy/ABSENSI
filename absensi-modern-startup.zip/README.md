
# Absensi Modern

Fitur:
- Login User dan Admin
- Selfie Absensi (kamera)
- Scan QR Code Absensi
- Grafik Kehadiran
- UI Modern

## Cara Jalankan

npm install
npm run dev

## Deploy

Upload project ini ke GitHub lalu deploy ke Vercel.
